# VDS2Raw：五个无监督域适应方法

本入口运行DANN、Deep CORAL、CDAN+E、MDD、MCC，独立于已有MCFT/TIR入口。

## 协议

- **UDA**：source_train的116条样本提供分类监督；target_train的94条样本只提供RGB/NIR/AIS输入，加载器不读取NPZ中的label字段，不向训练批次返回标签，不计算目标域CE或目标训练ACC。
- 每轮用target_val的28条样本选择最佳ACC，ACC相同时用macro-F1比较。
- 最佳完整模型状态暂存在CPU内存，训练结束后恢复；target_test的33条样本仅评价一次。不用测试集比较训练轮次。
- RGB/NIR统计、AIS标准化只使用source_train + target_train；数据完整性审计会检查全部271条NPZ的格式及跨分区场景/MMSI隔离。
- 本次按数据说明输入**完整13维AIS及13维有效性掩码**，包括导航状态；现有MCFT/TIR只用4维AIS的加载器不受影响，两种AIS协议的实验应分别标注。

## 模型与训练

五种方法共享三模态输入接口：ImageNet ResNet-18提取RGB特征；第二个ResNet-18提取NIR特征，其第一层由RGB权重沿通道求均值初始化；13维AIS乘掩码后与13维掩码拼接输入MLP。学习RGB/NIR/AIS三项全局权重后拼接特征。

输入图像保留96×96。训练时RGB/NIR共享填充裁剪、水平/垂直翻转，翻转同步修正AIS航向sin/cos；RGB有轻微亮度增益。评价完全确定，无随机增强。

域适应核心：DANN使用源域CE、源/目标域判别损失之和和梯度反转；Deep CORAL对分类logits进行无偏协方差对齐；CDAN+E使用外积条件域判别及熵加权；MDD使用仓库tllib的差异损失及负号/反转方向；MCC使用仓库tllib的最小类别混淆损失。全部仅用源域标签计算CE。

按参考实现恢复不同前向方式：DANN、Deep CORAL、CDAN分别前向源域和目标域；MDD/MCC在批次维拼接后联合前向。CDAN瓶颈为纯Linear、判别器两层1024；MDD主分类头和对抗头均为两层MLP，瓶颈保留Dropout。

Deep CORAL/CDAN的预训练骨干使用基准学习率，新层和判别器使用10倍；MDD/MCC骨干使用0.1倍、新层1倍。CDAN/MDD/MCC按更新次数使用inverse学习率调度；DANN/Deep CORAL默认常数学习率。原先所有方法统一使用的epoch余弦降到零已取消。

默认seed42、每域batch16、100 epochs；两域完整覆盖，较短域循环补足。取消统一的5轮纯分类预热和10轮迁移权重渐增；Deep CORAL沿整个预算渐增对齐权重，DANN/CDAN/MDD保留各自的GRL调度，MCC使用固定适配权重。默认标签平滑为0。每轮使用target_val选模，训练预算和全部超参数记录在run_config中。

### 2026-11-13：MDD/MCC定向优化配置

`--profile baseline`保留上一轮设置。新入口`run_server_vds2raw_mdd_mcc_background.sh`明确选择`--profile optimized`，只运行MDD、MCC，其他方法不受影响。

| 设置 | MDD原配置 | MDD优化配置 | MCC原配置 | MCC优化配置 |
| --- | --- | --- | --- | --- |
| epochs | 100 | 250 | 100 | 100 |
| batch/域 | 16 | 16 | 16 | 16 |
| 更新次数（116/94样本） | 800 | 2000 | 800 | 800 |
| 适配权重 | 0.30 | 0.60 | 0.20 | 0.50 |
| 图像骨干初始LR | 0.00025 | 0.00025 | 0.00020 | 0.00020 |
| 分类头/瓶颈/门控初始LR | 0.0025 | 0.0025 | 0.0020 | 0.0020 |
| AIS编码器初始LR | 0.0025 | 0.0125 | 0.0020 | 0.0100 |
| inverse LR gamma | 0.0002 | 0.0002 | 0.001 | 0.001 |

这些调整对应日志中源域拟合强、适配梯度较弱和AIS分支特征偏弱的现象：延长MDD的实际更新预算并增强适配梯度；MCC提高适配权重；AIS单列参数组。MDD负差异损失、GRL公式、MCC温度与核心损失均保持不变。AIS特征范数小不是因果证明，这组调整是待实验验证的优化配置，不保证准确率提升。

优化配置启动：

```bash
export VDS2RAW_SEEDS=42
bash scripts/run_server_vds2raw_mdd_mcc_background.sh formal
```

请不要继承旧的`VDS2RAW_DA_EPOCHS=100`覆盖MDD的250轮配置；启动前可`unset VDS2RAW_DA_EPOCHS`。直接CLI的`--epochs`、`--trade-off`、`--ais-lr-multiplier`具有更高优先级；实际参数和优化配置名写入日志及结果。MDD的gamma修正在上一轮之后完成，比较结果时必须同时记录这一差异。对照优化配置与原配置时，多个参数同时变化，不能把提升单独归因于某一项。

这是一套适配三模态数据接口的UDA实现；参数与骨干选择不等于原论文所有基准实验的逐项复刻。历史`vds2raw_sda_*`结果保留为SDA，不能改标签后当作UDA结果。

## 服务器启动

先同步本次新增文件到服务器项目目录。仅需已有ResNet-18权重，缺失时脚本自动调用下载工具。

```bash
cd /home/lixiang/lx/JMDA_Com
export PYTHON=/home/lixiang/envs/lx_pytorch/bin/python
export VDS2RAW_DATA_ROOT=/home/lixiang/lx/VDS2Raw/threeclass_ready
export VDS2RAW_GPU_CANDIDATES=0,1
export VDS2RAW_SEEDS=42
bash scripts/run_server_vds2raw_da_background.sh formal
```

每个方法开始前，选择连续3次检测显存空闲至少6144 MiB且GPU利用率不超过10%的GPU。没有满足条件的GPU则等待。默认每30秒检查一次。后台nohup运行，断开SSH后继续。

可配置环境变量：`VDS2RAW_DA_EPOCHS`、`VDS2RAW_DA_BATCH_SIZE`、`VDS2RAW_DA_METHODS`（空格或逗号分隔）、`VDS2RAW_SEEDS`（空格或逗号分隔）、`VDS2RAW_GPU_MAX_UTIL_PERCENT`、`VDS2RAW_DA_MIN_FREE_MIB`、`VDS2RAW_NUM_WORKERS`。

将启动参数`formal`换成`smoke`可执行每方法2轮、每轮1个批次的流程检查；此结果标记smoke，不用于性能报告。

## 结果与诊断

- 总日志：`server_logs/vds2raw_da_launcher/`；启动后打印准确日志路径和PID。
- 每方法训练日志：`runs/vds2raw_da/<运行目录>/logs/`。
- 测试集ACC、macro Precision/Recall/F1与复杂度：`<运行目录>/summary/runs.csv`。
- 多seed均值和标准差：`<运行目录>/summary/summary.csv`。
- 每方法`result.json`记录选模分区、最佳epoch、验证及最终测试结果、三模态权重、复杂度和预测文件路径。
- `training.jsonl`、`updates.jsonl`：源域CE、适配损失、权重、学习率、模态特征范数、样本覆盖及耗时。没有目标域真实标签统计。
- `gradients.jsonl`：每轮最后一个批次的RGB/NIR/AIS、分类头与门控的分类/适配梯度范数、比值及夹角。
- `evaluation.jsonl`、`predictions.jsonl`：每轮完整源域和验证集的分类指标、混淆矩阵及逐样本概率；目标训练集只记录无标签置信度、熵、预测类别分布及概率，禁止真实类别和正确性字段；测试集仅在结束时记录一次。
- `completeness.json`：强制检查诊断窗口、全部样本预测覆盖、概率合法性、单次测试与八项复杂度记录，缺失则任务报错。
- 八项复杂度：总参数、可训练参数、推理GFLOPs、训练总时间、平均epoch时间、单样本推理延迟、吞吐量、GPU训练峰值保留显存。GFLOPs为Conv2d/Linear计数，1 MAC=2 FLOPs；延迟为batch1本模型纯推理。
