"""Leakage-safe VDS2Raw dataset loading and audit utilities."""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from itertools import combinations
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset
from torchvision import transforms

CLASS_NAMES = ("Cargo", "Fishing", "Sailing_Pleasure")
DISPLAY_CLASS_NAMES = ("Cargo", "Fishing", "Sailing & Pleasure")
CLASS_TO_ID = {name: index for index, name in enumerate(CLASS_NAMES)}
PARTITIONS = ("source_train", "target_train", "target_val", "target_test")
TRAIN_PARTITIONS = ("source_train", "target_train")
EXPECTED_COUNTS = {
    "source_train": 116,
    "target_train": 94,
    "target_val": 28,
    "target_test": 33,
}
REQUIRED_KEYS = {"rgb", "nir", "ais", "ais_mask", "label"}
SAFE_AIS_FEATURE_INDICES = (0, 1, 2, 3)
SAFE_AIS_FEATURE_NAMES = ("heading_sin", "heading_cos", "length_z", "width_z")
EXCLUDED_AIS_PROXY_FEATURES = (
    "nav_<UNKNOWN>",
    "nav_at anchor",
    "nav_engaged in fishing",
    "nav_moored",
    "nav_reserved for future amendment [hsc]",
    "nav_restricted maneuverability",
    "nav_under way sailing",
    "nav_under way using engine",
    "nav_unknown value",
)


@dataclass(frozen=True)
class ImageStatistics:
    rgb_mean: tuple[float, float, float]
    rgb_std: tuple[float, float, float]
    rgb_min: tuple[float, float, float]
    rgb_max: tuple[float, float, float]
    nir_mean: tuple[float]
    nir_std: tuple[float]
    nir_min: tuple[float]
    nir_max: tuple[float]
    fit_partitions: tuple[str, ...] = TRAIN_PARTITIONS
    fit_samples: int = 210

    def to_dict(self):
        return {
            "rgb_mean": list(self.rgb_mean),
            "rgb_std": list(self.rgb_std),
            "rgb_min": list(self.rgb_min),
            "rgb_max": list(self.rgb_max),
            "nir_mean": list(self.nir_mean),
            "nir_std": list(self.nir_std),
            "nir_min": list(self.nir_min),
            "nir_max": list(self.nir_max),
            "fit_partitions": list(self.fit_partitions),
            "fit_samples": self.fit_samples,
            "rule": (
                "statistics fitted only on: " + " + ".join(self.fit_partitions)
            ),
        }

    @classmethod
    def from_dict(cls, payload, expected_fit_partitions=TRAIN_PARTITIONS):
        expected_fit_partitions = tuple(expected_fit_partitions)
        if tuple(payload["fit_partitions"]) != expected_fit_partitions:
            raise ValueError(
                "normalization statistics partition mismatch: expected "
                f"{expected_fit_partitions}, got {tuple(payload['fit_partitions'])}"
            )
        required_ranges = ("rgb_min", "rgb_max", "nir_min", "nir_max")
        missing_ranges = [key for key in required_ranges if key not in payload]
        if missing_ranges:
            raise ValueError(
                "normalization statistics predate raw-DN range tracking; "
                f"regenerate the stats file (missing {missing_ranges})"
            )
        return cls(
            rgb_mean=tuple(map(float, payload["rgb_mean"])),
            rgb_std=tuple(map(float, payload["rgb_std"])),
            rgb_min=tuple(map(float, payload["rgb_min"])),
            rgb_max=tuple(map(float, payload["rgb_max"])),
            nir_mean=tuple(map(float, payload["nir_mean"])),
            nir_std=tuple(map(float, payload["nir_std"])),
            nir_min=tuple(map(float, payload["nir_min"])),
            nir_max=tuple(map(float, payload["nir_max"])),
            fit_partitions=tuple(payload["fit_partitions"]),
            fit_samples=int(payload["fit_samples"]),
        )


def partition_files(root, partition):
    root = Path(root)
    if partition not in PARTITIONS:
        raise ValueError(f"unknown partition {partition!r}")
    files = []
    for class_name in CLASS_NAMES:
        class_dir = root / "samples" / partition / class_name
        if not class_dir.is_dir():
            raise FileNotFoundError(f"missing class directory: {class_dir}")
        files.extend(sorted(class_dir.glob("*.npz")))
    return files


def target_present_class_ids(root, partition="target_train"):
    """Return class IDs that have at least one sample in the target partition."""
    if not str(partition).startswith("target_"):
        raise ValueError(f"expected a target partition, got {partition!r}")
    present = {
        CLASS_TO_ID[path.parent.name]
        for path in partition_files(root, partition)
    }
    if not present:
        raise ValueError(f"target partition {partition!r} has no samples")
    return tuple(sorted(present))


def _filter_paths_by_class_ids(paths, allowed_class_ids):
    if allowed_class_ids is None:
        return list(paths)
    allowed = {int(class_id) for class_id in allowed_class_ids}
    unknown = allowed.difference(range(len(CLASS_NAMES)))
    if unknown:
        raise ValueError(f"unknown allowed class IDs: {sorted(unknown)}")
    filtered = [
        path for path in paths if CLASS_TO_ID[path.parent.name] in allowed
    ]
    if not filtered:
        raise ValueError(f"class filter {sorted(allowed)} removed every sample")
    return filtered


def compute_image_statistics(root, fit_partitions=TRAIN_PARTITIONS):
    """Fit RGB/NIR channel statistics using only the requested train data."""
    fit_partitions = tuple(fit_partitions)
    if not fit_partitions or any(
        partition not in TRAIN_PARTITIONS for partition in fit_partitions
    ):
        raise ValueError(
            "image statistics may only use source_train and/or target_train; "
            f"got {fit_partitions}"
        )
    sums = np.zeros(4, dtype=np.float64)
    squared = np.zeros(4, dtype=np.float64)
    counts = np.zeros(4, dtype=np.int64)
    minima = np.full(4, np.inf, dtype=np.float64)
    maxima = np.full(4, -np.inf, dtype=np.float64)
    sample_count = 0
    for partition in fit_partitions:
        for path in partition_files(root, partition):
            with np.load(path, allow_pickle=False) as item:
                arrays = (item["rgb"], item["nir"])
                channels = np.concatenate(
                    [arrays[0].reshape(3, -1), arrays[1].reshape(1, -1)], axis=0
                ).astype(np.float64, copy=False)
            sums += channels.sum(axis=1)
            squared += np.square(channels).sum(axis=1)
            counts += channels.shape[1]
            minima = np.minimum(minima, channels.min(axis=1))
            maxima = np.maximum(maxima, channels.max(axis=1))
            sample_count += 1
    means = sums / counts
    variances = np.maximum(squared / counts - np.square(means), 1e-12)
    stds = np.sqrt(variances)
    return ImageStatistics(
        rgb_mean=tuple(map(float, means[:3])),
        rgb_std=tuple(map(float, stds[:3])),
        rgb_min=tuple(map(float, minima[:3])),
        rgb_max=tuple(map(float, maxima[:3])),
        nir_mean=(float(means[3]),),
        nir_std=(float(stds[3]),),
        nir_min=(float(minima[3]),),
        nir_max=(float(maxima[3]),),
        fit_partitions=fit_partitions,
        fit_samples=sample_count,
    )


def load_or_compute_statistics(
    root, stats_file=None, fit_partitions=TRAIN_PARTITIONS
):
    fit_partitions = tuple(fit_partitions)
    stats_path = Path(stats_file) if stats_file else None
    if stats_path and stats_path.is_file():
        return ImageStatistics.from_dict(
            json.loads(stats_path.read_text(encoding="utf-8")),
            expected_fit_partitions=fit_partitions,
        )
    statistics = compute_image_statistics(root, fit_partitions=fit_partitions)
    if stats_path:
        stats_path.parent.mkdir(parents=True, exist_ok=True)
        temporary = stats_path.with_suffix(stats_path.suffix + ".tmp")
        temporary.write_text(
            json.dumps(statistics.to_dict(), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        temporary.replace(stats_path)
    return statistics


def _manifest_rows(root):
    manifest = Path(root) / "dataset_manifest.csv"
    with manifest.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def audit_dataset(root, check_every_sample=True):
    """Independently verify the stated partition and anti-leakage contract."""
    root = Path(root).expanduser().resolve()
    required_metadata = (
        "dataset_manifest.csv",
        "feature_schema.json",
        "build_report.json",
        "band_order_verification.json",
        "validation_report.json",
    )
    for name in required_metadata:
        if not (root / name).is_file():
            raise FileNotFoundError(f"missing VDS2Raw metadata file: {root / name}")

    schema = json.loads((root / "feature_schema.json").read_text(encoding="utf-8"))
    report = json.loads((root / "validation_report.json").read_text(encoding="utf-8"))
    if report.get("status") != "PASS":
        raise ValueError("validation_report.json status is not PASS")
    if tuple(schema.get("train_partitions", ())) != TRAIN_PARTITIONS:
        raise ValueError(
            "feature_schema.json permits non-training partitions in statistics"
        )
    if schema.get("feature_dim") != 13:
        raise ValueError("AIS feature_dim must be 13")
    feature_names = tuple(schema.get("ais_feature_names", ()))
    if feature_names[:4] != SAFE_AIS_FEATURE_NAMES:
        raise ValueError(
            "AIS feature schema no longer starts with the approved "
            f"heading/length/width fields: {feature_names[:4]}"
        )

    counts = {}
    disk_relpaths = set()
    for partition in PARTITIONS:
        files = partition_files(root, partition)
        counts[partition] = len(files)
        if counts[partition] != EXPECTED_COUNTS[partition]:
            raise ValueError(
                f"{partition} count mismatch: {counts[partition]} != "
                f"{EXPECTED_COUNTS[partition]}"
            )
        for path in files:
            disk_relpaths.add(path.relative_to(root).as_posix())
            if not check_every_sample:
                continue
            class_id = CLASS_TO_ID[path.parent.name]
            with np.load(path, allow_pickle=False) as item:
                if set(item.files) != REQUIRED_KEYS:
                    raise ValueError(f"invalid NPZ keys in {path}: {item.files}")
                if item["rgb"].shape != (3, 96, 96) or item["rgb"].dtype != np.uint16:
                    raise ValueError(f"invalid RGB tensor in {path}")
                if item["nir"].shape != (1, 96, 96) or item["nir"].dtype != np.uint16:
                    raise ValueError(f"invalid NIR tensor in {path}")
                if item["ais"].shape != (13,) or item["ais_mask"].shape != (13,):
                    raise ValueError(f"invalid AIS tensor in {path}")
                if not np.isfinite(item["ais"]).all():
                    raise ValueError(f"non-finite AIS values in {path}")
                if not np.isin(item["ais_mask"], (0.0, 1.0)).all():
                    raise ValueError(f"non-binary AIS mask in {path}")
                if int(item["label"]) != class_id:
                    raise ValueError(f"folder/NPZ label mismatch in {path}")

    rows = _manifest_rows(root)
    if len(rows) != sum(EXPECTED_COUNTS.values()):
        raise ValueError(f"manifest row count is {len(rows)}, expected 271")
    manifest_relpaths = {row["npz_relpath"].replace("\\", "/") for row in rows}
    if manifest_relpaths != disk_relpaths:
        raise ValueError("manifest NPZ file set does not exactly match samples/")
    if len({row["sample_id"] for row in rows}) != len(rows):
        raise ValueError("manifest sample_id values are not unique")

    overlap = {}
    for field in ("scene", "mmsi"):
        values = {
            partition: {
                row[field]
                for row in rows
                if row["partition"] == partition and row[field].strip()
            }
            for partition in PARTITIONS
        }
        for left, right in combinations(PARTITIONS, 2):
            common = values[left] & values[right]
            overlap[f"{field}:{left}__{right}"] = len(common)
            if common:
                raise ValueError(
                    f"{field} leakage between {left} and {right}: {common}"
                )

    return {
        "status": "PASS",
        "root": str(root),
        "counts": counts,
        "class_names": list(DISPLAY_CLASS_NAMES),
        "train_statistics_partitions": list(TRAIN_PARTITIONS),
        "overlap_counts": overlap,
        "model_ais_feature_names": list(SAFE_AIS_FEATURE_NAMES),
        "excluded_ais_proxy_features": list(EXCLUDED_AIS_PROXY_FEATURES),
        "ais_mask_usage": "missing-value gating only; not a classifier feature",
        "checked_every_sample": bool(check_every_sample),
    }


class VDS2RawDataset(Dataset):
    """Return RGB/NIR and proxy-safe continuous AIS fields.

    The prepared files retain the complete 13-field audit record, but models
    only receive heading (sin/cos), length, and width. Navigation-status
    one-hot values are direct vessel-class proxies and are removed at the
    loader boundary. The four validity bits are returned only for gating.
    """

    def __init__(
        self,
        root,
        partition,
        statistics,
        image_size=None,
        augment=False,
        allowed_class_ids=None,
    ):
        self.root = Path(root).expanduser().resolve()
        self.partition = partition
        self.statistics = statistics
        self.image_size = image_size
        self.augment = augment
        self.allowed_class_ids = (
            None
            if allowed_class_ids is None
            else tuple(sorted({int(value) for value in allowed_class_ids}))
        )
        self.paths = _filter_paths_by_class_ids(
            partition_files(self.root, partition), self.allowed_class_ids
        )
        self.samples = [
            (str(path), CLASS_TO_ID[path.parent.name]) for path in self.paths
        ]
        self.rgb_mean = torch.tensor(statistics.rgb_mean, dtype=torch.float32).view(
            3, 1, 1
        )
        self.rgb_std = torch.tensor(statistics.rgb_std, dtype=torch.float32).view(
            3, 1, 1
        )
        self.nir_mean = torch.tensor(statistics.nir_mean, dtype=torch.float32).view(
            1, 1, 1
        )
        self.nir_std = torch.tensor(statistics.nir_std, dtype=torch.float32).view(
            1, 1, 1
        )

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, index):
        path = self.paths[index]
        with np.load(path, allow_pickle=False) as item:
            rgb = torch.from_numpy(item["rgb"].astype(np.float32))
            nir = torch.from_numpy(item["nir"].astype(np.float32))
            ais = torch.from_numpy(
                item["ais"][list(SAFE_AIS_FEATURE_INDICES)].astype(np.float32)
            )
            ais_mask = torch.from_numpy(
                item["ais_mask"][list(SAFE_AIS_FEATURE_INDICES)].astype(np.float32)
            )
            label = int(item["label"])
        rgb = (rgb - self.rgb_mean) / self.rgb_std
        nir = (nir - self.nir_mean) / self.nir_std
        if self.image_size and self.image_size != 96:
            size = (self.image_size, self.image_size)
            rgb = F.interpolate(
                rgb.unsqueeze(0), size=size, mode="bilinear", align_corners=False
            ).squeeze(0)
            nir = F.interpolate(
                nir.unsqueeze(0), size=size, mode="bilinear", align_corners=False
            ).squeeze(0)
        if self.augment:
            if bool(torch.rand(()) < 0.5):
                rgb, nir = rgb.flip(-1), nir.flip(-1)
                # AIS heading uses (sin(theta), cos(theta)) for clockwise
                # degrees from north.  A left/right image reflection negates
                # the east/west component, i.e. heading_sin.
                ais[0] = -ais[0]
            if bool(torch.rand(()) < 0.5):
                rgb, nir = rgb.flip(-2), nir.flip(-2)
                # An up/down reflection negates the north/south component,
                # i.e. heading_cos. Invalid headings are already zero.
                ais[1] = -ais[1]
        return {
            "rgb": rgb,
            "nir": nir,
            "ais": ais,
            "ais_mask": ais_mask,
            "label": label,
            "path": str(path),
        }


class VDS2RawTIRDataset(Dataset):
    """VDS2Raw view for CLIP/TIR with paired RGB/NIR geometry.

    RGB follows the official CLIP ViT-B/16 224x224 normalization after
    8-bit-semantics scaling with sparse high-outlier clipping. NIR stays in train-fitted
    z-score space for the project-specific residual adapter. Only proxy-safe
    continuous AIS fields and their gating masks are returned. Random crop/flip
    parameters are shared by RGB and NIR, and heading components are corrected
    after reflections.
    """

    CLIP_MEAN = (0.48145466, 0.4578275, 0.40821073)
    CLIP_STD = (0.26862954, 0.26130258, 0.27577711)

    def __init__(
        self,
        root,
        partition,
        statistics,
        augment=False,
        image_size=224,
        allowed_class_ids=None,
    ):
        self.root = Path(root).expanduser().resolve()
        self.partition = partition
        self.statistics = statistics
        self.augment = bool(augment)
        self.image_size = int(image_size)
        if self.image_size != 224:
            raise ValueError("official CLIP ViT-B/16 requires image_size=224")
        self.allowed_class_ids = (
            None
            if allowed_class_ids is None
            else tuple(sorted({int(value) for value in allowed_class_ids}))
        )
        self.paths = _filter_paths_by_class_ids(
            partition_files(self.root, partition), self.allowed_class_ids
        )
        self.samples = [
            (str(path), CLASS_TO_ID[path.parent.name]) for path in self.paths
        ]
        self.nir_mean = torch.tensor(statistics.nir_mean, dtype=torch.float32).view(
            1, 1, 1
        )
        self.nir_std = torch.tensor(statistics.nir_std, dtype=torch.float32).view(
            1, 1, 1
        )
        self.clip_mean = torch.tensor(self.CLIP_MEAN, dtype=torch.float32).view(
            3, 1, 1
        )
        self.clip_std = torch.tensor(self.CLIP_STD, dtype=torch.float32).view(
            3, 1, 1
        )

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, index):
        path = self.paths[index]
        with np.load(path, allow_pickle=False) as item:
            rgb = torch.from_numpy(item["rgb"].astype(np.float32))
            nir = torch.from_numpy(item["nir"].astype(np.float32))
            ais = torch.from_numpy(
                item["ais"][list(SAFE_AIS_FEATURE_INDICES)].astype(np.float32)
            )
            ais_mask = torch.from_numpy(
                item["ais_mask"][list(SAFE_AIS_FEATURE_INDICES)].astype(np.float32)
            )
            label = int(item["label"])

        # Although stored in uint16 containers, 99% of training pixels are at
        # or below roughly 179/225/262 for R/G/B. Scaling by rare maxima above
        # 1000 makes normal vessels unnaturally dark for CLIP. Match the
        # official 8-bit ToTensor semantics and clip only sparse high outliers.
        rgb = (rgb / 255.0).clamp_(0.0, 1.0)
        # Rare raw sensor spikes exceed 20 standard deviations and destabilise
        # the small supervised NIR head. Robust clipping preserves virtually
        # all train-fitted signal while preventing a few pixels from dominating.
        nir = ((nir - self.nir_mean) / self.nir_std).clamp_(-5.0, 5.0)
        if self.augment:
            top, left, height, width = transforms.RandomResizedCrop.get_params(
                rgb, scale=(0.9, 1.0), ratio=(0.95, 1.05)
            )
            rgb = rgb[:, top : top + height, left : left + width]
            nir = nir[:, top : top + height, left : left + width]
            if bool(torch.rand(()) < 0.5):
                rgb, nir = rgb.flip(-1), nir.flip(-1)
                ais[0] = -ais[0]
            if bool(torch.rand(()) < 0.5):
                rgb, nir = rgb.flip(-2), nir.flip(-2)
                ais[1] = -ais[1]
        size = (self.image_size, self.image_size)
        rgb = F.interpolate(
            rgb.unsqueeze(0), size=size, mode="bicubic", align_corners=False
        ).squeeze(0)
        nir = F.interpolate(
            nir.unsqueeze(0), size=size, mode="bilinear", align_corners=False
        ).squeeze(0)
        rgb = (rgb.clamp_(0.0, 1.0) - self.clip_mean) / self.clip_std
        return {
            "rgb": rgb,
            "nir": nir,
            "ais": ais,
            "ais_mask": ais_mask,
            "label": label,
            "path": str(path),
        }


__all__ = [
    "CLASS_NAMES",
    "DISPLAY_CLASS_NAMES",
    "EXPECTED_COUNTS",
    "EXCLUDED_AIS_PROXY_FEATURES",
    "PARTITIONS",
    "SAFE_AIS_FEATURE_INDICES",
    "SAFE_AIS_FEATURE_NAMES",
    "TRAIN_PARTITIONS",
    "ImageStatistics",
    "VDS2RawDataset",
    "VDS2RawTIRDataset",
    "audit_dataset",
    "compute_image_statistics",
    "load_or_compute_statistics",
    "partition_files",
    "target_present_class_ids",
]
