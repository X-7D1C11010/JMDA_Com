# 本轮：仅更新VDS2Raw MCC和天气DANN/Deep CORAL

服务器上的MDD/DANN/Deep CORAL seed42–46正在运行，本轮不安排重跑。更新包只在项目根目录新增一个后台入口，并把其余代码放进`experiment_updates/mcc_weather_v2_20261113/`，解压不覆盖正在运行实验的公共Python或Shell文件。所有新任务使用现有GPU队列锁、共享已有ResNet-18权重，输出仍保存到原项目的runs目录。

## MCC为什么仍低，以及实际修改

上一轮MCC从42.42%提升至63.64%，最佳验证85.71%，测试21/33正确。17条Cargo中8条被判为Fishing。早期源域Cargo召回在第1/5轮为0，第10轮仅12.5%，第20轮50%；目标MCC损失却从第一轮开始参与优化。到末轮目标验证ACC75%，验证置信度93.3%、CE1.724。记录支持分类偏置与错误预测强化的风险，不能仅凭这些记录断定某一项是唯一原因。

独立`mcc_v2`配置：

| 设置 | 上一轮optimized | 本轮mcc_v2 |
| --- | --- | --- |
| 源域CE | 按样本均匀平均 | 按源类别频数加权 |
| 源域类别计数 | 16/41/59 | 相同；全部样本保留 |
| CE权重（Cargo/Fishing/Sailing） | 1/1/1 | 2.4167/0.9431/0.6554 |
| 分类预热 | 0轮 | 前20轮仅优化分类损失 |
| MCC渐增 | 立即0.50 | 第21–40轮增加至0.50 |
| 最大轮数 | 100 | 100 |
| LR / AIS倍率 / 温度 | 0.002 / 5 / 2.5 | 相同 |

权重仅用source_train标签计算，公式N/(C*n_c)，不读取目标训练标签来计算权重。预热期间目标输入仍参与联合前向和BN统计，MCC损失权重为0；这不是排除目标输入的源域独立预训练。不会根据测试指标调节模型。本轮保留完整100轮预算；旧日志中早期验证CE低于后来高ACC时的CE，因此没有把CDAN的CE早停直接套给MCC。

## 天气为什么低，以及实际修改

先前100轮对应2600–3300次更新，而VDS的100轮仅800次。源域在约第2–5轮达到99%，Deep CORAL对齐却到第100轮才升满，逆光最高75%随后降至55.56%；后期分类与对齐梯度有冲突。DANN域判别接近50%，黑天分类仍差且错误自信，这不能作为类别对齐成功的证据。分别前向时每个域各自进行BN标准化是需核验的训练机制。

独立`timing_v2`配置：

| 设置 | DANN原配置 | DANN本轮 | Deep CORAL原配置 | Deep CORAL本轮 |
| --- | --- | --- | --- | --- |
| 最大轮数 | 100 | 40 | 100 | 40 |
| 基准LR | 0.0003 | 0.00015 | 0.0005 | 0.0001 |
| 实际骨干/新层LR | 0.00003/0.0003 | 0.000015/0.00015 | 0.0005/0.005 | 0.0001/0.001 |
| 最大适配权重 | 0.35 | 0.20 | 0.30 | 0.10 |
| 适配渐增 | GRL渐增，损失权重立即全开 | GRL保留，损失权重再用5轮渐增 | 损失权重100轮渐增 | 损失权重5轮渐增 |
| 域前向 | 源、目标分别前向 | 拼到一个batch联合前向 | 源、目标分别前向 | 拼到一个batch联合前向 |
| LR调度 | 常数 | 40轮余弦 | 常数 | 40轮余弦 |
| 早停 | 关闭 | 至少20轮，ACC/F1连续15轮未提高 | 关闭 | 同左 |

两域在每个模态分支内共用当前batch的BN统计，减少分别标准化造成的训练/评价差异；仍只有源域CE使用真值。DANN仍为BCE域对抗，Deep CORAL仍对分类logits做协方差对齐。骨干、VIS/IR加权拼接、JMDA图像增强、精确配对和目标类别驱动的源域筛选均沿用。每轮完整覆盖源/目标，batch16；40轮对应1040–1320次更新，实际更新数和早停原因写入结果。

联合前向和新的更新节奏是需要实际验证的修改，不是日志已证明的唯一根因；这组联合修改的收益也不能单独归因于某一个参数。天气仍报告验证ACC最高轮次，VDS仍验证选模后只测试一次。

新增诊断：分类CE的加权/未加权值、瓶颈前/后的源目标均值与标准差差距；原有梯度夹角/范数、各类召回、混淆矩阵、门控权重、置信度、覆盖统计、八项复杂度继续记录。

## 服务器启动：本轮9个任务

将`mcc_weather_v2_update.zip`上传到项目根目录：

```bash
cd /home/lixiang/lx/JMDA_Com
export PYTHON=/home/lixiang/envs/lx_pytorch/bin/python
"$PYTHON" -m zipfile -e mcc_weather_v2_update.zip .
export VDS2RAW_DATA_ROOT=/home/lixiang/lx/VDS2Raw/threeclass_ready
export JMDA_DATA_ROOT=/mnt/data/lixiang/data/Data
export VDS2RAW_GPU_CANDIDATES=0,1
export JMDA_GPU_CANDIDATES=0,1
bash scripts/run_server_mcc_weather_v2_background.sh 42
```

顺序为MCC的VDS2Raw seed42一次，然后天气两方法×四天气，共9次。GPU空闲显存/利用率满足条件才启动；可以断开SSH。MCC结果目录带`mcc_v2`，天气目录带`timing_v2`；总日志位于`server_logs/pending_adaptation_v2_launcher/`。训练尚未由本助手启动，正式精度以本轮实验结果为准。
