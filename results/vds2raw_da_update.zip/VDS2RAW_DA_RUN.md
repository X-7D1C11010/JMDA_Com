# VDS2Raw：五个域适应方法

本入口运行DANN、Deep CORAL、CDAN+E、MDD、MCC，独立于已有MCFT/TIR入口。

## 协议

- **SDA**：source_train的116条与target_train的94条样本全部标签可见，均计算分类损失，同时保留相应方法的适配损失。不得称为原论文的UDA实验。
- 每轮用target_val的28条样本选择最佳ACC，ACC相同时用macro-F1比较。
- 最佳完整模型状态暂存在CPU内存，训练结束后恢复；target_test的33条样本仅评价一次。不用测试集比较训练轮次。
- RGB/NIR统计、AIS标准化只使用source_train + target_train；数据完整性审计会检查全部271条NPZ的格式及跨分区场景/MMSI隔离。
- 本次按数据说明输入**完整13维AIS及13维有效性掩码**，包括导航状态；现有MCFT/TIR只用4维AIS的加载器不受影响，两种AIS协议的实验应分别标注。

## 模型与训练

五种方法共享三模态输入接口：ImageNet ResNet-18提取RGB特征；第二个ResNet-18提取NIR特征，其第一层由RGB权重沿通道求均值初始化；13维AIS乘掩码后与13维掩码拼接输入MLP。学习RGB/NIR/AIS三项全局权重后拼接特征。

输入图像保留96×96。训练时RGB/NIR共享填充裁剪、水平/垂直翻转，翻转同步修正AIS航向sin/cos；RGB有轻微亮度增益。评价完全确定，无随机增强。

域适应核心：DANN梯度反转与域判别；Deep CORAL对分类logits的无偏协方差对齐；CDAN+E外积条件域判别及熵加权；MDD使用仓库tllib的官方差异损失及负号/反转方向；MCC使用仓库tllib的官方最小类别混淆损失。新增目标域CE和三模态接口属于此数据集的有监督扩展。

默认seed42、每域batch16、100 epochs；两域完整覆盖，较短域循环补足。前5轮仍同时使用两域标签监督，仅适配项预热；随后10轮渐增适配权重。默认不提前停止；每轮评价并选模。参数是新数据集的初始配置，尚未经正式训练验证。

## 服务器启动

先同步本次新增文件到服务器项目目录。仅需已有ResNet-18权重，缺失时脚本自动调用下载工具。

```bash
cd /home/lixiang/lx/JMDA_Com
export PYTHON=/home/lixiang/envs/lx_pytorch/bin/python
export VDS2RAW_DATA_ROOT=/home/lixiang/lx/VDS2Raw/threeclass_ready
export VDS2RAW_GPU_CANDIDATES=0,1
export VDS2RAW_SEEDS=42
bash scripts/run_server_vds2raw_da_background.sh formal
```

每个方法开始前，选择连续3次检测显存空闲至少6144 MiB且GPU利用率不超过10%的GPU。没有满足条件的GPU则等待。默认每30秒检查一次。后台nohup运行，断开SSH后继续。

可配置环境变量：`VDS2RAW_DA_EPOCHS`、`VDS2RAW_DA_BATCH_SIZE`、`VDS2RAW_DA_METHODS`（空格或逗号分隔）、`VDS2RAW_SEEDS`（空格或逗号分隔）、`VDS2RAW_GPU_MAX_UTIL_PERCENT`、`VDS2RAW_DA_MIN_FREE_MIB`、`VDS2RAW_NUM_WORKERS`。

将启动参数`formal`换成`smoke`可执行每方法2轮、每轮1个批次的流程检查；此结果标记smoke，不用于性能报告。

## 结果与诊断

- 总日志：`server_logs/vds2raw_da_launcher/`；启动后打印准确日志路径和PID。
- 每方法训练日志：`runs/vds2raw_da/<运行目录>/logs/`。
- 测试集ACC、macro Precision/Recall/F1与复杂度：`<运行目录>/summary/runs.csv`。
- 多seed均值和标准差：`<运行目录>/summary/summary.csv`。
- 每方法`result.json`记录选模分区、最佳epoch、验证及最终测试结果、三模态权重、复杂度和预测文件路径。
- `training.jsonl`、`updates.jsonl`：两域CE、适配损失、权重、学习率、模态特征范数、样本覆盖及耗时。
- `gradients.jsonl`：每轮最后一个批次的RGB/NIR/AIS、分类头与门控的分类/适配梯度范数、比值及夹角。
- `evaluation.jsonl`、`predictions.jsonl`：每轮完整源域、目标训练集和验证集的指标、混淆矩阵及逐样本概率；测试集仅在结束时记录一次。
- `completeness.json`：强制检查诊断窗口、全部样本预测覆盖、概率合法性、单次测试与八项复杂度记录，缺失则任务报错。
- 八项复杂度：总参数、可训练参数、推理GFLOPs、训练总时间、平均epoch时间、单样本推理延迟、吞吐量、GPU训练峰值保留显存。GFLOPs为Conv2d/Linear计数，1 MAC=2 FLOPs；延迟为batch1本模型纯推理。
