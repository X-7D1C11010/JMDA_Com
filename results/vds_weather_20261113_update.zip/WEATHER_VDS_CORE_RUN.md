# 天气数据：复用VDS2Raw修正后的DANN/Deep CORAL核心

本入口按用户2026-11-13的选择，实现天气数据适配器，直接调用`vds2raw.adaptation.AdaptationModel`及共享优化器。它不使用历史参数存档中的天气训练核心，也不启动JMDA/Ablation。

## 实验设置

- 晴天为源域；逆光、雨天、雾天、黑天分别为目标域。每种方法、每种天气完整训练一次，seed42。两方法×四天气，共8个任务，依次执行。
- 默认每任务100 epochs，每域batch16，DANN初始LR为骨干0.00003/新层0.0003、适配权重0.35、Adam；Deep CORAL初始LR为骨干0.0005/新层0.005、最大适配权重0.30、SGD，CORAL权重在完整训练预算中线性增加。没有纯分类预热或默认早停。
- VDS2Raw训练核心保持不变：DANN源域CE加双域BCE及GRL，Deep CORAL源域CE加分类logits的无偏协方差对齐，分别进行源域和目标域前向。
- 输入改为VIS+IR；两支均为独立ImageNet预训练ResNet-18，IR灰度重复为3通道，无AIS分支。每个方法、每个天气学习一组全局权重（各权重在0.05和0.95之间，总和为1），按`concat(2*w_vis*f_vis, 2*w_ir*f_ir)`拼接。分类头宽度由该天气目标类别数确定。
- 精确同文件名VIS/IR配对。只保留该目标天气存在的源域类别，全部保留这些类别的源样本，使用一份连续类别映射；不会为了匹配目标域样本数丢弃额外源样本。
- 已知目标类别集合只用于预处理和类别支持检查；训练目标数据来自不含标签的`*_train_pairs.tsv`。数据视图不返回目标标签，目标域不计算CE或分类ACC。评价诊断不记录目标训练集真值。
- 每轮覆盖较大域全部样本，较小域循环补足，源/目标批次各16。每轮记录两域唯一覆盖量和暴露次数，避免隐含丢样本。
- 增强严格调用现有JMDA图像变换：训练Resize256×256、RandomCrop224、水平翻转；VIS/IR共享随机几何。验证Resize224×224、确定性变换。VIS用ImageNet归一化，IR用0.5均值和标准差。
- 每轮完整评价source_train及target_val；target_train只生成无标签诊断。按target_val最高ACC选择，ACC相同取macro-F1较高的一轮，P/R/F1全部取同一轮。最佳完整状态保存在CPU内存，不写模型文件。
- 天气数据没有独立target_test，此入口汇报的是**本次预算内的target_val峰值**，不能标为独立测试集准确率；VDS2Raw仍在选模后只评价一次target_test。

## 服务器启动

先将本次代码同步到服务器项目根目录。

```bash
cd /home/lixiang/lx/JMDA_Com
export PYTHON=/home/lixiang/envs/lx_pytorch/bin/python
export JMDA_DATA_ROOT=/mnt/data/lixiang/data/Data
export JMDA_GPU_CANDIDATES=0,1
bash scripts/run_server_weather_vds_core_background.sh 42
```

只需`pretrained_weights/torch/hub/checkpoints/resnet18-f37072fd.pth`，缺失则调用已有下载工具。脚本启动前创建共享精确配对清单；每个任务在GPU空闲显存≥8192 MiB、利用率≤10%、连续3次检测满足时运行，默认间隔30秒。无合适GPU会排队。使用已有GPU调度器共享锁，nohup后台运行，断开SSH后继续。

可通过`WEATHER_VDS_EPOCHS`、`WEATHER_VDS_BATCH_SIZE`、`WEATHER_VDS_NUM_WORKERS`、`WEATHER_VDS_MIN_FREE_MIB`、`WEATHER_VDS_EVAL_BATCH_SIZE`覆盖预算与资源设置；`WEATHER_VDS_TARGETS`为空格分隔天气列表。默认无需设置。启动打印总日志和PID，逐方法日志会显示排队或训练进度。

## 输出

- 总日志：`server_logs/weather_vds_core_launcher/`。
- 每次结果根目录：`runs/weather_vds_core/weather_uda_seed42_<时间戳>/`。
- 汇总：`summary/runs.csv`及`summary/results.md`，每任务结束后更新。
- 每任务：`dataset_audit.json`、`run_config.json`、`updates.jsonl`、`training.jsonl`、`gradients.jsonl`、`evaluation.jsonl`、`predictions.jsonl`、`selected_target_val_predictions.json`、`completeness.json`、`result.json`。
- 记录源域拟合、源/目标特征范数、域判别ACC、GRL系数、适配损失/权重、学习率、VIS/IR全局权重、每模态分类/迁移梯度及夹角、目标预测熵/置信度/类别分布，和验证集逐类召回/CE/混淆矩阵。
- 八项复杂度：总参数、可训练参数、Conv/Linear推理GFLOPs、训练总时间、平均epoch训练时间、batch1推理延迟、吞吐量、训练峰值保留显存。计时不含GPU排队和评价，包含梯度诊断开销。

流程检查使用合成图片，不会自动启动用户数据上的正式训练。准确率需由上述实际实验确认。
