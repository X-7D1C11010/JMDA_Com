# VDS2Raw：五个无监督域适应方法

本入口运行DANN、Deep CORAL、CDAN+E、MDD、MCC，独立于已有MCFT/TIR入口。

## 协议

- **UDA**：source_train的116条样本提供分类监督；target_train的94条样本只提供RGB/NIR/AIS输入，加载器不读取NPZ中的label字段，不向训练批次返回标签，不计算目标域CE或目标训练ACC。
- 每轮用target_val的28条样本选择最佳ACC，ACC相同时用macro-F1比较。
- 最佳完整模型状态暂存在CPU内存，训练结束后恢复；target_test的33条样本仅评价一次。不用测试集比较训练轮次。
- RGB/NIR统计、AIS标准化只使用source_train + target_train；数据完整性审计会检查全部271条NPZ的格式及跨分区场景/MMSI隔离。
- 本次按数据说明输入**完整13维AIS及13维有效性掩码**，包括导航状态；现有MCFT/TIR只用4维AIS的加载器不受影响，两种AIS协议的实验应分别标注。

## 模型与训练

五种方法共享三模态输入接口：ImageNet ResNet-18提取RGB特征；第二个ResNet-18提取NIR特征，其第一层由RGB权重沿通道求均值初始化；13维AIS乘掩码后与13维掩码拼接输入MLP。学习RGB/NIR/AIS三项全局权重后拼接特征。

输入图像保留96×96。训练时RGB/NIR共享填充裁剪、水平/垂直翻转，翻转同步修正AIS航向sin/cos；RGB有轻微亮度增益。评价完全确定，无随机增强。

域适应核心：DANN使用源域CE、源/目标域判别损失之和和梯度反转；Deep CORAL对分类logits进行无偏协方差对齐；CDAN+E使用外积条件域判别及熵加权；MDD使用仓库tllib的差异损失及负号/反转方向；MCC使用仓库tllib的最小类别混淆损失。全部仅用源域标签计算CE。

按参考实现恢复不同前向方式：DANN、Deep CORAL、CDAN分别前向源域和目标域；MDD/MCC在批次维拼接后联合前向。CDAN瓶颈为纯Linear、判别器两层1024；MDD主分类头和对抗头均为两层MLP，瓶颈保留Dropout。

Deep CORAL/CDAN的预训练骨干使用基准学习率，新层和判别器使用10倍；MDD/MCC骨干使用0.1倍、新层1倍。CDAN/MDD/MCC按更新次数使用inverse学习率调度；DANN/Deep CORAL默认常数学习率。原先所有方法统一使用的epoch余弦降到零已取消。

默认seed42、每域batch16、100 epochs；两域完整覆盖，较短域循环补足。取消统一的5轮纯分类预热和10轮迁移权重渐增；Deep CORAL沿整个预算渐增对齐权重，DANN/CDAN/MDD保留各自的GRL调度，MCC使用固定适配权重。默认标签平滑为0。每轮使用target_val选模，训练预算和全部超参数记录在run_config中。

### 2026-11-13：MDD/MCC定向优化配置

`--profile baseline`保留上一轮设置。新入口`run_server_vds2raw_mdd_mcc_background.sh`明确选择`--profile optimized`，只运行MDD、MCC，其他方法不受影响。

| 设置 | MDD原配置 | MDD优化配置 | MCC原配置 | MCC优化配置 |
| --- | --- | --- | --- | --- |
| epochs | 100 | 250 | 100 | 100 |
| batch/域 | 16 | 16 | 16 | 16 |
| 更新次数（116/94样本） | 800 | 2000 | 800 | 800 |
| 适配权重 | 0.30 | 0.60 | 0.20 | 0.50 |
| 图像骨干初始LR | 0.00025 | 0.00025 | 0.00020 | 0.00020 |
| 分类头/瓶颈/门控初始LR | 0.0025 | 0.0025 | 0.0020 | 0.0020 |
| AIS编码器初始LR | 0.0025 | 0.0125 | 0.0020 | 0.0100 |
| inverse LR gamma | 0.0002 | 0.0002 | 0.001 | 0.001 |

这些调整对应日志中源域拟合强、适配梯度较弱和AIS分支特征偏弱的现象：延长MDD的实际更新预算并增强适配梯度；MCC提高适配权重；AIS单列参数组。MDD负差异损失、GRL公式、MCC温度与核心损失均保持不变。AIS特征范数小不是因果证明，这组调整是待实验验证的优化配置，不保证准确率提升。

优化配置启动：

```bash
export VDS2RAW_SEEDS=42
bash scripts/run_server_vds2raw_mdd_mcc_background.sh formal
```

请不要继承旧的`VDS2RAW_DA_EPOCHS=100`覆盖MDD的250轮配置；启动前可`unset VDS2RAW_DA_EPOCHS`。直接CLI的`--epochs`、`--trade-off`、`--ais-lr-multiplier`具有更高优先级；实际参数和优化配置名写入日志及结果。MDD的gamma修正在上一轮之后完成，比较结果时必须同时记录这一差异。对照优化配置与原配置时，多个参数同时变化，不能把提升单独归因于某一项。

这是一套适配三模态数据接口的UDA实现；参数与骨干选择不等于原论文所有基准实验的逐项复刻。历史`vds2raw_sda_*`结果保留为SDA，不能改标签后当作UDA结果。

## 服务器启动

### 本次CDAN实际训练修改与四方法统一入口

此前CDAN五seed追加脚本只改变了启动范围，训练策略未改。本次在`optimized`配置中实际加入以下控制，baseline仍保留原设置：

| 项目 | CDAN baseline | CDAN optimized（本次） |
| --- | --- | --- |
| 核心损失、骨干、输入 | 原CDAN+E、RGB/NIR/AIS | 相同 |
| 初始LR / 迁移权重 / AIS倍率 | 0.0005 / 1 / 1 | 相同 |
| 最大轮数 | 100 | 100 |
| 验证损失平台期降LR | 关闭 | 验证CE连续12轮未改善，LR乘0.5 |
| 平台期最小倍率 | 1 | 0.1，与原inverse调度相乘 |
| 早停监控 | 关闭 | 验证CE |
| 早停条件 | 关闭 | 至少50轮，CE连续20轮未改善 |
| CE改善阈值 | 不适用 | 绝对下降超过0.0001 |
| 最终状态选择 | 最高验证ACC，其次macro-F1 | 相同 |
| 测试评价 | 恢复选中状态后一次 | 相同 |

CE负责调节训练和停止，ACC/F1负责选最终状态。目标训练集真值不参与，测试指标不参与任何控制。新增`validation_control.jsonl`逐轮记录CE、CE最佳轮次、停滞计数、LR倍率、下一轮各组LR和停止决定；`result.json`及汇总表记录停止原因及实际轮数。平台期倍率会与原inverse更新时钟组合，避免下一次LambdaLR更新覆盖降LR结果。

一次运行四方法×五seed，共20个任务：

```bash
cd /home/lixiang/lx/JMDA_Com
export PYTHON=/home/lixiang/envs/lx_pytorch/bin/python
export VDS2RAW_DATA_ROOT=/home/lixiang/lx/VDS2Raw/threeclass_ready
export VDS2RAW_GPU_CANDIDATES=0,1
bash scripts/run_server_vds2raw_four_methods_background.sh formal
```

MDD沿用250轮配置；DANN、Deep CORAL沿用100轮配置；CDAN使用以上修改，最多100轮。每域batch16，seed42–46，后台依次执行、GPU空闲检测、保存逐次指标/跨seed统计/八项复杂度。前三方法如果已经在运行，只追加：

```bash
bash scripts/run_server_vds2raw_cdan_seeds_background.sh formal
```

本包对天气DANN/Deep CORAL未做参数或训练流程修改；此前天气部分仅完成诊断，不应表述为已完成天气优化。本次只检查合成流程，不启动实际数据训练。

### MDD、DANN、Deep CORAL：seed42–46正式实验

本入口固定运行三个方法，每个方法使用42、43、44、45、46五个seed，共15次完整训练。沿用已验证的配置：MDD使用优化配置（250轮、迁移权重0.60、AIS学习率倍率5、inverse gamma=0.0002）；DANN/Deep CORAL使用上一轮的100轮配置，AIS学习率倍率为1。全部每域batch16、workers2、确定性训练。

入口使用`optimized`配置名，但该配置在DANN和Deep CORAL上与`baseline`的实际参数完全相同；不会把MDD的250轮或AIS倍率5套到其他方法。入口清除旧的全局epoch环境变量，避免意外把MDD覆盖为100轮。seed42也在新目录重新运行，旧结果保留。

```bash
cd /home/lixiang/lx/JMDA_Com
export PYTHON=/home/lixiang/envs/lx_pytorch/bin/python
export VDS2RAW_DATA_ROOT=/home/lixiang/lx/VDS2Raw/threeclass_ready
export VDS2RAW_GPU_CANDIDATES=0,1
bash scripts/run_server_vds2raw_three_methods_background.sh formal
```

执行顺序为seed42的MDD/DANN/Deep CORAL，然后seed43，依次至seed46。每个任务独立检查GPU空闲显存和利用率，队列等待不计训练时间；nohup运行，断开SSH继续。每次任务完成即更新`summary/runs.csv`和`summary/summary.csv`，后者记录各方法已完成seed的ACC、Precision、Recall、F1均值与标准差（沿用总体标准差ddof=0）。最终应为15条单次记录、3条五seed汇总记录。

数据仍为RGB+NIR+AIS及mask的UDA：仅源域有标签监督、目标训练无标签；target_val逐轮选模，target_test每次训练结束后仅评价一次。八项复杂度和完整诊断按原流程记录。将参数`formal`改为`smoke`仅检查流程，不能用于性能报告。

### 通用五方法入口

单独追加CDAN的seed42–46：

```bash
bash scripts/run_server_vds2raw_cdan_seeds_background.sh formal
```

此入口只运行CDAN，不重复已经启动的MDD/DANN/Deep CORAL。现已切换到以上CDAN optimized配置，包括验证CE平台期降LR和CE早停。它不是旧版“只增加五seed、不改训练策略”的入口。早停监控CE而非ACC：旧记录第10轮到第49轮之间ACC/F1不再创高，但CE仍改善；直接对ACC使用patience20会提前结束。五seed用于检查稳定性，不以单次100%作为稳定性结论。

先同步本次新增文件到服务器项目目录。仅需已有ResNet-18权重，缺失时脚本自动调用下载工具。

```bash
cd /home/lixiang/lx/JMDA_Com
export PYTHON=/home/lixiang/envs/lx_pytorch/bin/python
export VDS2RAW_DATA_ROOT=/home/lixiang/lx/VDS2Raw/threeclass_ready
export VDS2RAW_GPU_CANDIDATES=0,1
export VDS2RAW_SEEDS=42
bash scripts/run_server_vds2raw_da_background.sh formal
```

每个方法开始前，选择连续3次检测显存空闲至少6144 MiB且GPU利用率不超过10%的GPU。没有满足条件的GPU则等待。默认每30秒检查一次。后台nohup运行，断开SSH后继续。

可配置环境变量：`VDS2RAW_DA_EPOCHS`、`VDS2RAW_DA_BATCH_SIZE`、`VDS2RAW_DA_METHODS`（空格或逗号分隔）、`VDS2RAW_SEEDS`（空格或逗号分隔）、`VDS2RAW_GPU_MAX_UTIL_PERCENT`、`VDS2RAW_DA_MIN_FREE_MIB`、`VDS2RAW_NUM_WORKERS`。

将启动参数`formal`换成`smoke`可执行每方法2轮、每轮1个批次的流程检查；此结果标记smoke，不用于性能报告。

## 结果与诊断

- 总日志：`server_logs/vds2raw_da_launcher/`；启动后打印准确日志路径和PID。
- 每方法训练日志：`runs/vds2raw_da/<运行目录>/logs/`。
- 测试集ACC、macro Precision/Recall/F1与复杂度：`<运行目录>/summary/runs.csv`。
- 多seed均值和标准差：`<运行目录>/summary/summary.csv`。
- 每方法`result.json`记录选模分区、最佳epoch、验证及最终测试结果、三模态权重、复杂度和预测文件路径。
- `training.jsonl`、`updates.jsonl`：源域CE、适配损失、权重、学习率、模态特征范数、样本覆盖及耗时。没有目标域真实标签统计。
- `gradients.jsonl`：每轮最后一个批次的RGB/NIR/AIS、分类头与门控的分类/适配梯度范数、比值及夹角。
- `evaluation.jsonl`、`predictions.jsonl`：每轮完整源域和验证集的分类指标、混淆矩阵及逐样本概率；目标训练集只记录无标签置信度、熵、预测类别分布及概率，禁止真实类别和正确性字段；测试集仅在结束时记录一次。
- `completeness.json`：强制检查诊断窗口、全部样本预测覆盖、概率合法性、单次测试与八项复杂度记录，缺失则任务报错。
- 八项复杂度：总参数、可训练参数、推理GFLOPs、训练总时间、平均epoch时间、单样本推理延迟、吞吐量、GPU训练峰值保留显存。GFLOPs为Conv2d/Linear计数，1 MAC=2 FLOPs；延迟为batch1本模型纯推理。
